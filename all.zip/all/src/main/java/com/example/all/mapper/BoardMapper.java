package com.example.all.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Insert;

import com.example.all.domain.Board;
import com.example.all.dto.PageDTO;

public interface BoardMapper {

    @Insert("insert into tbl_board(title,content,writer) values (#{title}, #{content},#{writer})")
    void insert(Board board);

    List<Board> getList();

    List<Board> getPage(PageDTO pageDTO);
}
