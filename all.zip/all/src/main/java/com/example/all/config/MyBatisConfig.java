package com.example.all.config;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@MapperScan(basePackages =  {"com.example.all.mapper"})
public class MyBatisConfig {
    
}
