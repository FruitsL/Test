package com.example.all.dto;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class PageDTO {
    
    @Builder.Default
    private int page = 1;
    private int size = 10;

    private String keyword;

    //t,tc,tcw
    private String type;

    public int getSkip(){
        return (page-1)*size;
    }

    public String[] getTypes(){
        if(type != null){return null;};

        return type.split("");
    }

}
