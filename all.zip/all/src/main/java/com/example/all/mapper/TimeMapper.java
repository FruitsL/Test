package com.example.all.mapper;

import org.apache.ibatis.annotations.Select;

public interface TimeMapper {
    
    @Select("select now()")
    String getTime();

    String getTime2(); // 메소드 이름이 id, 이를 통해 쿼리문을 찾는다?

}
