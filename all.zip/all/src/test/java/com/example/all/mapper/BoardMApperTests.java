package com.example.all.mapper;
import java.util.stream.IntStream;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.all.domain.Board;
import com.example.all.dto.PageDTO;

import lombok.extern.log4j.Log4j2;

@SpringBootTest
@Log4j2
public class BoardMApperTests {
    @Autowired(required = false)
    BoardMapper mapper;

    @Test
    public void testInsert10(){
        
        IntStream.rangeClosed(1, 10)
        .forEach(i ->{
            Board board = Board.builder()
            .title("title")
            .content("content")
            .writer("writer")
            .build();

            mapper.insert(board);
        });
    }


    @Test
    public void testList(){

        mapper.getList().forEach(board -> log.info(board));

    }

    @Test
    public void testPage(){
        PageDTO pageDTO = new PageDTO();
        pageDTO.setPage(3);
        pageDTO.setSize(15);

        mapper.getPage(pageDTO).forEach(board->log.info(board));
        

    }

}
