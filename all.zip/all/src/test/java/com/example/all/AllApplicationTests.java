package com.example.all;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AllApplicationTests {

	@Test
	void contextLoads() {
	}

}
