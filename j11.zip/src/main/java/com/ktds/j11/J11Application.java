package com.ktds.j11;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

@SpringBootApplication
@EnableJpaAuditing // 날짜와 시간 처리
public class J11Application {

	public static void main(String[] args) {
		SpringApplication.run(J11Application.class, args);
	}

}
