package com.ktds.j11.repository.search;

import org.springframework.data.domain.Page;

import com.ktds.j11.dto.PageRequestDTO;
import com.ktds.j11.entity.TodoEntity;

public interface TodoSearch {
    Page<TodoEntity> list(PageRequestDTO dto);
}
