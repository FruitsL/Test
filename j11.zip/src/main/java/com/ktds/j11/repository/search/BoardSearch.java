package com.ktds.j11.repository.search;

import org.springframework.data.domain.Page;

import com.ktds.j11.dto.BoardDTO;
import com.ktds.j11.dto.PageRequestDTO;

public interface BoardSearch {
    Page<BoardDTO> list(PageRequestDTO dto);
}
