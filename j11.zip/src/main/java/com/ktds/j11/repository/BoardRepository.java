package com.ktds.j11.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ktds.j11.entity.Board;
import com.ktds.j11.repository.search.BoardSearch;

public interface BoardRepository extends JpaRepository<Board, Long>, BoardSearch {
    Page<Board> findByTitleContains(String keyword, Pageable pageable);

    @Query(value = "select b.bno, b.title from Board b where b.title like %:keyword% order by b.bno desc")
    Page<Object[]> getList1(@Param("keyword") String keyword, Pageable pageable);
}
