package com.ktds.j11.repository.search;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.support.QuerydslRepositorySupport;

import com.ktds.j11.dto.PageRequestDTO;
import com.ktds.j11.dto.TodoDTO;
import com.ktds.j11.dto.TodoSearchDTO;
import com.ktds.j11.entity.QTodoEntity;
import com.ktds.j11.entity.TodoEntity;
import com.querydsl.core.BooleanBuilder;
import com.querydsl.core.types.Projections;
import com.querydsl.jpa.JPQLQuery;

import lombok.extern.log4j.Log4j2;

@Log4j2
public class TodoSearchImpl extends QuerydslRepositorySupport implements TodoSearch {
    public TodoSearchImpl() {
        super(TodoEntity.class);
    }

    @Override
    public Page<TodoEntity> list(PageRequestDTO dto) {
        log.info("-----------------list");
        QTodoEntity board = QTodoEntity.todoEntity;
        JPQLQuery query = from(board);

        // 검색 조건 처리
        BooleanBuilder booleanBuilder = new BooleanBuilder();
        String[] arr = dto.getTypes();
        String keyword = dto.getKeyword();

        Pageable pageable = dto.getPageable("tno");
        TodoSearchDTO searchDTO = (TodoSearchDTO) dto;
        
        if(keyword != null) {
            query.where(board.content.contains(keyword));
        }

        if(keyword != null && arr != null){
            for (String type : arr) {
                if(keyword == null) {
                    break;
                }
                switch(type) {
                    case "c":
                        booleanBuilder.or(board.content.contains(keyword));
                        break;
                }
            }
        }
        query.where(booleanBuilder);
        query.where(board.tno.gt(0L));

        // paging
        JPQLQuery<TodoEntity> pagingQuery = this.getQuerydsl().applyPagination(pageable, query);
        long total = pagingQuery.fetchCount();

        JPQLQuery<TodoDTO> dtoQuery = pagingQuery.select(Projections.bean(TodoDTO.class, 
            board.tno, board.complete, board.content, board.regDate, board.dueDate, board.modDate));

        return new PageImpl(dtoQuery.fetch(), pageable, total);
    }
}
