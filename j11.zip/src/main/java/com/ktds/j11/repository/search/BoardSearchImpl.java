package com.ktds.j11.repository.search;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.support.QuerydslRepositorySupport;

import com.ktds.j11.dto.BoardDTO;
import com.ktds.j11.dto.PageRequestDTO;
import com.ktds.j11.entity.Board;
import com.ktds.j11.entity.QBoard;
import com.querydsl.core.BooleanBuilder;
import com.querydsl.core.types.Projections;
import com.querydsl.jpa.JPQLQuery;

import lombok.extern.log4j.Log4j2;

@Log4j2
public class BoardSearchImpl extends QuerydslRepositorySupport implements BoardSearch {
    public BoardSearchImpl() {
        super(Board.class);
    }

    @Override
    public Page<BoardDTO> list(PageRequestDTO dto) {
        log.info("-----------------list");
        QBoard board = QBoard.board;
        JPQLQuery query = from(board);

        // 검색 조건 처리
        BooleanBuilder booleanBuilder = new BooleanBuilder();
        String[] arr = dto.getTypes();
        String keyword = dto.getKeyword();

        Pageable pageable = dto.getPageable("bno");


        if(keyword != null && arr != null){
            for (String type : arr) {
                if(keyword == null) {
                    break;
                }
                switch(type) {
                    case "t":
                        booleanBuilder.or(board.title.contains(keyword));
                        break;
                    case "c":
                        booleanBuilder.or(board.content.contains(keyword));
                        break;
                    case "w":
                        booleanBuilder.or(board.writer.contains(keyword));
                        break;
                }
            }
        }
        query.where(booleanBuilder);
        query.where(board.bno.gt(0L));

        // paging
        JPQLQuery pagingQuery = this.getQuerydsl().applyPagination(pageable, query);
        long total = pagingQuery.fetchCount();

        JPQLQuery<BoardDTO> dtoQuery = pagingQuery.select(Projections.bean(BoardDTO.class, 
            board.bno, board.title, board.writer, board.regDate));

        return new PageImpl(dtoQuery.fetch(), pageable, total);
    }
}
