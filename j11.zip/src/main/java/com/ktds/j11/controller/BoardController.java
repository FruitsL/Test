package com.ktds.j11.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ktds.j11.dto.PageRequestDTO;
import com.ktds.j11.service.BoardService;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

@Controller
@RequestMapping("/board/*")
@Log4j2
@RequiredArgsConstructor
public class BoardController {
    private final BoardService service;

    @GetMapping("/{bno}")
    public String read(@PathVariable("bno") Long bno) {
        log.info("bno: " + bno); // return type이 null이면 화면의 이름

        return "/board/read"; // board의 read.html
    }

    @GetMapping("/list")
    public void list(PageRequestDTO pageRequestDTO, Model model) { // 파라미터 수집, 데이터 전달
        log.info("--------------------------");
        log.info(pageRequestDTO);
        log.info("Board List...");

        String[] arr = new String[]{"111", "222", "333"};
        model.addAttribute("responseDTO", service.list(pageRequestDTO));
        model.addAttribute("arr", arr);
    }
}
