package com.ktds.j11.service;

import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ktds.j11.dto.BoardDTO;
import com.ktds.j11.dto.PageRequestDTO;
import com.ktds.j11.dto.PageResponseDTO;
import com.ktds.j11.repository.BoardRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

@RequiredArgsConstructor
@Log4j2
@Service
@Transactional
public class BoardServiceImpl implements BoardService {
    private final BoardRepository repository;

    @Override
    public PageResponseDTO<BoardDTO> list(PageRequestDTO pageRequestDTO) {
        Page<BoardDTO> result = repository.list(pageRequestDTO);

        return PageResponseDTO.<BoardDTO>withAll()
                .pageRequestDTO(pageRequestDTO)
                .dtoList(result.getContent())
                .total((int)result.getTotalElements())
                .build();
    }
}
