package com.ktds.j11.service;

import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ktds.j11.dto.PageRequestDTO;
import com.ktds.j11.dto.PageResponseDTO;
import com.ktds.j11.entity.TodoEntity;
import com.ktds.j11.repository.TodoRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

@RequiredArgsConstructor
@Log4j2
@Service
@Transactional
public class TodoServiceImpl implements TodoService {
    private final TodoRepository repository;

    @Override
    public PageResponseDTO<TodoEntity> list(PageRequestDTO pageRequestDTO) {
        Page<TodoEntity> result = repository.list(pageRequestDTO);

        return PageResponseDTO.<TodoEntity>withAll()
                .pageRequestDTO(pageRequestDTO)
                .dtoList(result.getContent())
                .total((int)result.getTotalElements())
                .build();
    }
}
