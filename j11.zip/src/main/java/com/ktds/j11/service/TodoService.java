package com.ktds.j11.service;

import com.ktds.j11.dto.PageRequestDTO;
import com.ktds.j11.dto.PageResponseDTO;
import com.ktds.j11.entity.TodoEntity;

public interface TodoService {
    PageResponseDTO<TodoEntity> list(PageRequestDTO pageRequestDTO);
}
