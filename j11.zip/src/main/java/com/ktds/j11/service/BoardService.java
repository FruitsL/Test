package com.ktds.j11.service;

import com.ktds.j11.dto.BoardDTO;
import com.ktds.j11.dto.PageRequestDTO;
import com.ktds.j11.dto.PageResponseDTO;

public interface BoardService {
    PageResponseDTO<BoardDTO> list(PageRequestDTO pageRequestDTO);
}
