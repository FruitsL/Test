package com.ktds.j11;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class J11ApplicationTests {

	@Test
	void contextLoads() {
	}

}
