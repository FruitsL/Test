package com.ktds.j11.repository;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.Arrays;
import java.util.Optional;
import java.util.stream.IntStream;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import com.ktds.j11.dto.BoardDTO;
import com.ktds.j11.dto.PageRequestDTO;
import com.ktds.j11.entity.Board;

import lombok.extern.log4j.Log4j2;

@SpringBootTest
@Log4j2
public class BoardRepositoryTests {
    @Autowired
    BoardRepository repository;

    @Test
    public void testList() {
        PageRequestDTO dto = PageRequestDTO.builder()
        .keyword("11")
        .type("tcw").build();
        Page<BoardDTO> result = repository.list(dto);
        result.getContent().forEach(board -> log.info(board));
        log.info(result.getTotalPages());
    }

    @Test
    public void testQueryMethod() {
        Pageable pageable = PageRequest.of(0, 10, Sort.by("bno").descending());
        Page<Board> result = repository.findByTitleContains("1", pageable);

        log.info(result);
        log.info(result.getTotalPages());
        log.info(result.isFirst());
        result.getContent().forEach(board -> log.info(board));
    }

    @Test
    public void testQuery() {
        Pageable pageable = PageRequest.of(0, 10);
        Page<Object[]> result = repository.getList1("11", pageable);
        result.getContent().forEach(arr -> log.info(Arrays.toString(arr)));
    }

    @Test
    public void testPaging() {
        Pageable pageable = PageRequest.of(0, 10, Sort.by("bno").descending());
        Page<Board> result = repository.findAll(pageable);
        log.info(result);
        log.info(result.getTotalPages());
        log.info(result.isFirst());
        log.info(result.getNumber());
        result.getContent().forEach(board -> log.info(board));
    }

    @Test
    public void testUpdate() {
        Optional<Board> result = repository.findById(3L);

        Board board = result.orElseThrow(); // 없으면 예외를 던짐
        
        board.changeTitle("AAA");
        board.changeContent("BBB");

        repository.save(board);
    }

    @Test
    public void testDelete() {
        Long bno = 1L;
        repository.deleteById(bno);
    }

    @Test
    public void testSelectOne() {
        Optional<Board> result = repository.findById(1L);

        Board board = result.orElseThrow(); // 없으면 예외를 던짐

        log.info(board);
    }

    @Test
    public void testInsert() {
        log.info(repository);
        assertNotNull(repository);

        IntStream.rangeClosed(1, 999).forEach(i -> {
            Board board = Board.builder()
            .title("title..." + i)
            .content("content..." + i)
            .writer("user" + (i % 10))
            .build();
            
            // db insert
            repository.save(board);
        });
    }
}
